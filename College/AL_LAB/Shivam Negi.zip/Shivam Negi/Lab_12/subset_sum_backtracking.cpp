#include <iostream>

using namespace std;

int sum(int inc[], int size)
{
    int res = 0;
    for(int i = 0; i < size; i++)
        res += inc[i];
    return res;
}

void disp(int inc[], int size)
{
    for(int i = 0; i < size; i++)
        cout<<inc[i]<<"\t";
    cout<<endl;
}

void subset_sum(int s[], int d, int inc[], int pos, int curr, int size)
{
    if(sum(inc, pos) == d)
        disp(inc, pos);
    else
    {
        for(int i = curr; i < size; i++)
        {
            inc[pos] = s[i];
            subset_sum(s, d, inc, pos + 1, i + 1, size);
            inc[pos] = 0;
            subset_sum(s, d, inc, pos, i + 1, size);
        }   
    }
}


int main()
{
    int n;
    cout<<"Enter the number of elements you want to enter: ";
    cin>>n;
    
    int a[n], inc[n];
    cout<<"Enter the array: ";
    for(int i = 0; i < n; i++)
    {
        cin>>a[i];
        inc[i] = 0;
    }
    
    int d;
    cout<<"Enter the value of d: ";
    cin>>d;
    
    subset_sum(a, d, inc, 0, 0, n);
    return 0;
}
